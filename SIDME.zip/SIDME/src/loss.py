import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import torch
import torchvision
from common import *
from torchvision import models as tv
from torch.nn.parameter import Parameter
import os
import cv2
import matplotlib.pyplot as plt

criterion_l1 = torch.nn.L1Loss().cuda()
def compute_color_loss(out, target):
    out = out.cpu()
    out = torch.clamp(out, 0, 1).mul(255).byte().numpy().squeeze(0).transpose((1, 2, 0))
    target = target.cpu()
    target = torch.clamp(target, 0, 1).mul(255).byte().numpy().squeeze(0).transpose((1, 2, 0))
    # lab die out
    # out_Lab = torch.from_numpy(cv2.cvtColor(out, cv2.COLOR_RGB2Lab)).float().div(255.0).cuda()
    # target_Lab = torch.from_numpy(cv2.cvtColor(target, cv2.COLOR_RGB2Lab)).float().div(255.0).cuda()
    # loss_color = (criterion_l1(out_Lab[:,:,1],target_Lab[:,:,1])+criterion_l1(out_Lab[:,:,2],target_Lab[:,:,2]))/2
    out_Hsv = torch.from_numpy(cv2.cvtColor(out, cv2.COLOR_RGB2HSV)).float().div(255.0).cuda()
    target_Hsv = torch.from_numpy(cv2.cvtColor(target, cv2.COLOR_RGB2HSV)).float().div(255.0).cuda()
    loss_color = (criterion_l1(out_Hsv[:,:,0],target_Hsv[:,:,0])+criterion_l1(out_Hsv[:,:,1],target_Hsv[:,:,1]))/2
    return loss_color

class multi_VGGPerceptualLoss(torch.nn.Module):
    def __init__(self, lam=1, lam_p=1):
        super(multi_VGGPerceptualLoss, self).__init__()
        self.loss_fn = VGGPerceptualLoss()
        self.lam = lam
        self.lam_p = lam_p
    def forward(self, out1, out2, out3, gt1, feature_layers=[2]):
        gt2 = F.interpolate(gt1, scale_factor=0.5, mode='bilinear', align_corners=False)
        gt3 = F.interpolate(gt1, scale_factor=0.25, mode='bilinear', align_corners=False)
        # print(gt1.size())
        # print(out1.size())
        # exit()
        loss1 = (self.lam_p*self.loss_fn(out1, gt1, feature_layers=feature_layers) + self.lam*F.l1_loss(out1, gt1))/(self.lam_p+self.lam)
        loss2 = (self.lam_p*self.loss_fn(out2, gt2, feature_layers=feature_layers) + self.lam*F.l1_loss(out2, gt2))/(self.lam_p+self.lam)
        loss3 = (self.lam_p*self.loss_fn(out3, gt3, feature_layers=feature_layers) + self.lam*F.l1_loss(out3, gt3))/(self.lam_p+self.lam)
        # print(self.lam)
        # print(self.lam_p)
        # exit()
        return (loss1+loss2+loss3)/3            

class VGGPerceptualLoss(torch.nn.Module):
    def __init__(self, resize=True):
        super(VGGPerceptualLoss, self).__init__()
        blocks = []
        blocks.append(torchvision.models.vgg16(pretrained=True).features[:4].eval())
        blocks.append(torchvision.models.vgg16(pretrained=True).features[4:9].eval())
        blocks.append(torchvision.models.vgg16(pretrained=True).features[9:16].eval())
        blocks.append(torchvision.models.vgg16(pretrained=True).features[16:23].eval())
        for bl in blocks:
            for p in bl:
                p.requires_grad = False
        self.blocks = torch.nn.ModuleList(blocks)
        self.transform = torch.nn.functional.interpolate
        self.mean = torch.nn.Parameter(torch.tensor([0.485, 0.456, 0.406]).view(1,3,1,1))
        self.std = torch.nn.Parameter(torch.tensor([0.229, 0.224, 0.225]).view(1,3,1,1))
        self.resize = resize

    def forward(self, input, target, feature_layers=[0, 1, 2, 3], style_layers=[]):
        if input.shape[1] != 3:
            input = input.repeat(1, 3, 1, 1)
            target = target.repeat(1, 3, 1, 1)
        input = (input-self.mean) / self.std
        target = (target-self.mean) / self.std
        if self.resize:
            input = self.transform(input, mode='bilinear', size=(224, 224), align_corners=False)
            target = self.transform(target, mode='bilinear', size=(224, 224), align_corners=False)
        loss = 0.0
        cnt = 0.0
        x = input
        y = target
        for i, block in enumerate(self.blocks):
            x = block(x)
            y = block(y)
            if i in feature_layers:
                loss += torch.nn.functional.l1_loss(x, y)
                cnt += 1.0
            if i in style_layers:
                act_x = x.reshape(x.shape[0], x.shape[1], -1)
                act_y = y.reshape(y.shape[0], y.shape[1], -1)
                gram_x = act_x @ act_x.permute(0, 2, 1)
                gram_y = act_y @ act_y.permute(0, 2, 1)
                loss += torch.nn.functional.l1_loss(gram_x, gram_y)
                cnt += 1.0
        return loss/cnt

class LossFunc(nn.Module):
    """
    loss function of BPN
    """

    def __init__(self, gradient_L1=True):
        super(LossFunc, self).__init__()
        self.loss_basic = LossBasic(gradient_L1)

    def forward(self, pred, ground_truth):
        """
        forward function of loss_func
        :param pred_burst: shape [batch_size, burst_length, color_channel, height, width]
        :param pred: shape [batch_size, color_channel, height, width]
        :param ground_truth: shape [batch_size, color_channel, height, width]
        :param global_step: int
        :return: loss
        """
        return self.loss_basic(pred,ground_truth)

class LossBasic(nn.Module):
    """
    Basic loss function.
    """

    def __init__(self, gradient_L1=True):
        super(LossBasic, self).__init__()
        self.l1_loss = nn.L1Loss()
        self.l2_loss = nn.MSELoss()
        self.gradient = TensorGradient(gradient_L1)

    def forward(self, pred, ground_truth):
        return self.l2_loss(pred, ground_truth) + \
               self.l1_loss(self.gradient(pred), self.gradient(ground_truth))

class TensorGradient(nn.Module):
    """
    the gradient of tensor
    """

    def __init__(self, L1=True):
        super(TensorGradient, self).__init__()
        self.L1 = L1

    def forward(self, img):
        w, h = img.size(-2), img.size(-1)
        l = F.pad(img, [1, 0, 0, 0])
        r = F.pad(img, [0, 1, 0, 0])
        u = F.pad(img, [0, 0, 1, 0])
        d = F.pad(img, [0, 0, 0, 1])
        if self.L1:
            return torch.abs((l - r)[..., 0:w, 0:h]) + torch.abs(
                (u - d)[..., 0:w, 0:h])
        else:
            return torch.sqrt(
                torch.pow((l - r)[..., 0:w, 0:h], 2) + torch.pow(
                    (u - d)[..., 0:w, 0:h], 2)
            )