# import os
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import torch.nn as nn
import torch.nn.functional as F
import torch
from torchvision.models import vgg19
import math

class ResidualBlock(nn.Module):
    def __init__(self, in_features):
        super(ResidualBlock, self).__init__()
        self.conv_block = nn.Sequential(
            nn.Conv2d(in_features, in_features, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(in_features, 0.8),
            nn.PReLU(),
            nn.Conv2d(in_features, in_features, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(in_features, 0.8),
        )

    def forward(self, x):
        return x + self.conv_block(x)

class GeneratorResNet(nn.Module):
    def __init__(self, in_channels=3, out_channels=3, n_residual_blocks=4):
        super(GeneratorResNet, self).__init__()

        # First layer
        self.conv1 = nn.Sequential(nn.Conv2d(in_channels, 16, kernel_size=9, stride=1, padding=4), nn.PReLU())

        # Residual blocks
        res_blocks = []
        for _ in range(n_residual_blocks):
            res_blocks.append(ResidualBlock(16))
        self.res_blocks = nn.Sequential(*res_blocks)

        # Second conv layer post residual blocks
        self.conv2 = nn.Sequential(nn.Conv2d(16, 16, kernel_size=3, stride=1, padding=1), nn.BatchNorm2d(16, 0.8))

        # Upsampling layers
        # upsampling = []
        # for out_features in range(2):
        #     upsampling += [
        #         # nn.Upsample(scale_factor=2),
        #         nn.Conv2d(64, 256, 3, 1, 1),
        #         nn.BatchNorm2d(256),
        #         nn.PixelShuffle(upscale_factor=2),
        #         nn.PReLU(),
        #     ]
        # self.upsampling = nn.Sequential(*upsampling)

        # Final output layer
        self.conv3 = nn.Sequential(nn.Conv2d(16, out_channels, kernel_size=9, stride=1, padding=4), nn.Tanh())

    def forward(self, x):
        out1 = self.conv1(x)
        # print("out1: ", out1.shape)
        out = self.res_blocks(out1)
        # print("out2: ", out.shape)
        out2 = self.conv2(out)
        # print("out3: ", out2.shape)
        out = torch.add(out1, out2)
        # print("out4: ", out.shape)
        # out = self.upsampling(out)
        # print("out5: ", out.shape)
        out = self.conv3(out)
        # print("out6: ", out.shape)
        return out

class DoubleConv(nn.Module):
    """(convolution => [BN] => ReLU) * 2"""
    def __init__(self, in_channels, out_channels, mid_channels=None):
        super().__init__()
        if not mid_channels:
            mid_channels = out_channels
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
    def forward(self, x):
        return self.double_conv(x)

class Down(nn.Module):
    """Downscaling with maxpool then double conv"""
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.maxpool_conv = nn.Sequential(
            DoubleConv(in_channels, out_channels, out_channels // 2)
        )
    def forward(self, x):
        x = F.interpolate(x, scale_factor = 0.5)
        return self.maxpool_conv(x)

class Up(nn.Module):
    """Upscaling then double conv"""
    def __init__(self, in_channels, out_channels, bilinear=True):
        super().__init__()

        # if bilinear, use the normal convolutions to reduce the number of channels
        self.conv = DoubleConv(in_channels, out_channels, in_channels // 2)

    def forward(self, x):
        x = F.interpolate(x, scale_factor = 2)
        return self.conv(x)

class Up_block(nn.Module):
    """Upscaling then double conv"""
    def __init__(self, in_channels, out_channels, bilinear=True):
        super().__init__()

        # if bilinear, use the normal convolutions to reduce the number of channels
        self.conv = DoubleConv(in_channels, out_channels, in_channels // 2)

    def forward(self, x1, x2):
        diffY = x2.size()[2] - x1.size()[2]
        diffX = x2.size()[3] - x1.size()[3]
        x1 = F.pad(x1, [diffX // 2, diffX - diffX // 2,
                        diffY // 2, diffY - diffY // 2])
        # if you have padding issues, see
        # https://github.com/HaiyongJiang/U-Net-Pytorch-Unstructured-Buggy/commit/0e854509c2cea854e247a9c615f175f76fbb2e3a
        # https://github.com/xiaopeng-liao/Pytorch-UNet/commit/8ebac70e633bac59fc22bb5195e513d5832fb3bd
        x = torch.cat([x2, x1], dim=1)
        return self.conv(x)

class Discriminator_Unet(nn.Module):
    def __init__(self, input_shape):
        super(Discriminator_Unet, self).__init__()

        self.input_shape = input_shape
        in_channels, in_height, in_width = self.input_shape
        # patch_h, patch_w = int(in_height / 2 ** 4), int(in_width / 2 ** 4)
        # self.output_shape = (1, patch_h, patch_w)
        self.output_shape = (1, 1, 1)

        self.conv_combine = nn.Sequential(
            nn.Conv2d(in_channels*2, in_channels, kernel_size=3, stride=1, padding=1, bias=True),
            nn.ReLU(inplace=True)
        )
        layers = [16, 32, 64, 128, 256, 512, 1024]
        self.inc = DoubleConv(in_channels, layers[0])
        self.down1 = Down(layers[0], layers[1])
        self.down2 = Down(layers[1], layers[2])
        self.down3 = Down(layers[2], layers[3])
        self.down4 = Down(layers[3], layers[4])
        self.down5 = Down(layers[4], layers[5])
        self.down6 = Down(layers[5], layers[6])

        self.up6 = Up(layers[6], layers[5])
        self.up_block6 = Up_block(layers[6], layers[5])

        self.up5 = Up(layers[5], layers[4])
        self.up_block5 = Up_block(layers[5], layers[4])

        self.up4 = Up(layers[4], layers[3])
        self.up_block4 = Up_block(layers[4], layers[3])

        self.up3 = Up(layers[3], layers[2])
        self.up_block3 = Up_block(layers[3], layers[2])

        self.up2 = Up(layers[2], layers[1])
        self.up_block2 = Up_block(layers[2], layers[1])

        self.up1 = Up(layers[1], layers[0])
        self.up_block1 = Up_block(layers[1], layers[0])

        self.outc = DoubleConv(layers[0], 1)

    def forward(self, x1, x2):
        x = self.conv_combine(torch.cat((x1,x2),dim=1))

        x_d_1 = self.inc(x)
        x_d_2 = self.down1(x_d_1)
        x_d_3 = self.down2(x_d_2)
        x_d_4 = self.down3(x_d_3)
        x_d_5 = self.down4(x_d_4)
        x_d_6 = self.down5(x_d_5)
        x_d_7 = self.down6(x_d_6)

        x_u_6 = self.up6(x_d_7)
        x_u_6_o = self.up_block6(x_u_6, x_d_6)

        x_u_5 = self.up5(x_u_6_o)
        x_u_5_o = self.up_block5(x_u_5, x_d_5)

        x_u_4 = self.up4(x_u_5_o)
        x_u_4_o = self.up_block4(x_u_4, x_d_4)

        x_u_3 = self.up3(x_u_4_o)
        x_u_3_o = self.up_block3(x_u_3, x_d_3)

        x_u_2 = self.up2(x_u_3_o)
        x_u_2_o = self.up_block2(x_u_2, x_d_2)

        x_u_1 = self.up1(x_u_2_o)
        x_u_1_o = self.up_block1(x_u_1, x_d_1)

        out = self.outc(x_u_1_o)
        # return torch.mean(out)
        return out

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    a = torch.rand(1, 3, 1024, 1024).cuda()
    b = torch.rand(1, 3, 1024, 1024).cuda()
    model = Discriminator_Unet(input_shape=(3, 1024, 1024)).to(device)

    out = model(a, b)
