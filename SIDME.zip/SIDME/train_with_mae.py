# coding: utf-8
# python
import os
import time
import sys
sys.path.append('src')
sys.path.append('src/gan')
import argparse
import warnings
warnings.filterwarnings('ignore')
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import numpy as np
# 3rd party
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
# torch
import torch
torch.cuda.current_device()
import torch.nn as nn
from torch.autograd import Variable
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
import itertools
# self
from network import *
from net_mae import *
from utils import *
from loss import *
from pipeline_revisel1 import *
from srgan_gan_cat_2_giga import *

import ssl
ssl._create_default_https_context = ssl._create_unverified_context

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
set_seed(1999)
warnings.filterwarnings('ignore')
torch.set_default_tensor_type(torch.FloatTensor)
cudnn.benchmark = True

# read config
# Params
parser = argparse.ArgumentParser(description='PyTorch ESDNet')
parser.add_argument('--model', default='My_With_Mae', type=str, help='choose a type of model')
parser.add_argument('--datasets_category', default='SynMoire', type=str, help='category of datasets, include:Synthetic')
parser.add_argument('--epochs', default=2000, type=int, help='number of train epoches')
parser.add_argument('--lr', default=0.0003, type=float, help='initial learning rate for Adam')
# parser.add_argument('--val_ratio', default=0.75, type=int, help='ratio of val data in train dataset')
parser.add_argument('--target_size', default=(256, 256), type=int, help='ratio of val data in train dataset')
parser.add_argument('--train_batch_size', default=1, type=int, help='ratio of val data in train dataset')
parser.add_argument('--val_batch_size', default=1, type=int, help='ratio of val data in train dataset')
parser.add_argument('--threads', default=0, type=int, help='ratio of val data in train dataset')
parser.add_argument('--aug_list', default=["rot", "rotate"], type=list, help='ratio of val data in train dataset')
parser.add_argument('--EN_FEATURE_NUM', default=16, type=int, help='The initial channel number of dense blocks of encoder')
parser.add_argument('--EN_INTER_NUM', default=16, type=int, help='The growth rate (intermediate channel number) of dense blocks of encoder')
parser.add_argument('--DE_FEATURE_NUM', default=24, type=int, help='The initial channel number of dense blocks of decoder')
parser.add_argument('--DE_INTER_NUM', default=16, type=int, help='The growth rate (intermediate channel number) of dense blocks of decoder')
parser.add_argument('--SAM_NUMBER', default=3, type=int, help='The number of SAM for each encoder or decoder level; set 1 for our ESDNet, and 2 for ESDNet-L')
parser.add_argument('--LAM', default=1, type=int, help='The loss weight for L1 loss')
parser.add_argument('--LAM_P', default=1, type=int, help='The loss weight for perceptual loss')
parser.add_argument('--LAM_GAN', default=0.1, type=int, help='The loss weight for gan loss')
parser.add_argument('--LAM_COLOR', default=10, type=int, help='The loss weight for L1 loss')
parser.add_argument('--LAM_BPNLOSS', default=10, type=int, help='The loss weight for L1 loss')
parser.add_argument('--LAM_FFT', default=0.1, type=int, help='The loss weight for perceptual loss')
parser.add_argument('--LAM_L1', default=1, type=int, help='The loss weight for L1 loss')
parser.add_argument('--channels', default=1, type=int, help='channel num of the image')
parser.add_argument('--layer_num', default=3, type=int, help='layer num of the net')
parser.add_argument('--mask_ratio', default=0.25, type=int, help='layer num of the net')
parser.add_argument("--b1", type=float, default=0.5, help="adam: decay of first order momentum of gradient")
parser.add_argument("--b2", type=float, default=0.999, help="adam: decay of first order momentum of gradient")
# Loss
parser.add_argument('--alpha', default=0.9998, type=float, help='')
parser.add_argument('--beta', default=100.0, type=float, help='')

args = parser.parse_args()
model_load_dir = os.path.join('models', args.model+'_'+ args.datasets_category)
model_save_dir = os.path.join('models', args.model+'_'+ args.datasets_category)
# model_load_dir = os.path.join('models', args.model+'_'+ args.datasets_category+'_revisel1')
train_source1_data = os.path.join('../../datasets/', args.datasets_category, 'train', 'moire')
# train_source2_data = os.path.join('../../data/datasets/', args.datasets_category, 'train', 'moire_gray')
train_target_data = os.path.join('../../datasets/', args.datasets_category, 'train', 'target')
val_source1_data = os.path.join('../../datasets/', args.datasets_category, 'val', 'moire')
# val_source2_data = os.path.join('../../data/datasets/', args.datasets_category, 'val', 'moire_gray')
val_target_data = os.path.join('../../datasets/', args.datasets_category, 'val', 'target')
train_data_path = os.path.join('datasets', args.datasets_category, 'train_data.csv')
val_data_path = os.path.join('datasets', args.datasets_category, 'val_data.csv')

if not os.path.exists(model_save_dir):
    os.mkdir(model_save_dir)

# if os.path.getsize(train_data_path) == 0:
train_source1_dataset_info = get_img_info(train_source1_data)
# train_source2_dataset_info = get_img_info_shuffle(train_source2_data)
train_target_dataset_info = get_img_info(train_target_data)
val_source1_dataset_info = get_img_info(val_source1_data)
# val_source2_dataset_info = get_img_info_shuffle(val_source2_data)
val_target_dataset_info = get_img_info(val_target_data)
save_data_path_single(train_source1_dataset_info, train_target_dataset_info, train_data_path)
save_data_path_single(val_source1_dataset_info, val_target_dataset_info, val_data_path)

train_dataset_info = get_path_data(train_data_path)
val_dataset_info = get_path_data(val_data_path)

train_dataset = GenerateDataset_single(train_dataset_info, args)
val_dataset = GenerateDataset_single(val_dataset_info, args)

train_dataloader = torch.utils.data.DataLoader(
    train_dataset,
    batch_size=args.train_batch_size,
    shuffle=True,
    num_workers=args.threads,
    worker_init_fn=worker_init_fn
)
val_dataloader = torch.utils.data.DataLoader(
    val_dataset,
    batch_size=args.val_batch_size,
    shuffle=False,
    num_workers=args.threads,
    worker_init_fn=worker_init_fn
)
#define model
model = my_model(en_feature_num=args.EN_FEATURE_NUM, en_inter_num=args.EN_INTER_NUM, de_feature_num=args.DE_FEATURE_NUM,
                de_inter_num=args.DE_INTER_NUM, sam_number=args.SAM_NUMBER)
model_mae = my_model_reconstructor(en_feature_num=args.EN_FEATURE_NUM, en_inter_num=args.EN_INTER_NUM, de_feature_num=args.DE_FEATURE_NUM,
                de_inter_num=args.DE_INTER_NUM, sam_number=args.SAM_NUMBER)


model.to(device)
model_mae.to(device)

#define loss
criterion = multi_VGGPerceptualLoss(lam=args.LAM, lam_p=args.LAM_P).to(device)
criterion_GAN = torch.nn.MSELoss().to(device)
criterion_content = torch.nn.L1Loss().to(device)
loss_func = LossFunc(
        gradient_L1=True,
    ).to(device)

#define optimizer
optimizer = optim.Adam(itertools.chain(model.parameters(), model_mae.parameters()), lr=args.lr, betas = (0.9, 0.999))

cuda = torch.cuda.is_available()
Tensor = torch.cuda.FloatTensor if cuda else torch.Tensor

best_train_psnr_performance = 0.0
best_val_psnr_performance = 0.0
best_psnr_train_epoch = 0
best_psnr_val_epoch = 0
best_train_ssim_performance = 0.0
best_val_ssim_performance = 0.0
best_ssim_train_epoch = 0
best_ssim_val_epoch = 0
best_train_lpips_performance = 100.0
best_val_lpips_performance = 100.0
best_lpips_train_epoch = 0
best_lpips_val_epoch = 0
lr = args.lr
step = 0
step_stage2 = 0

for epoch in range(args.epochs):
    print('*'*66)
    #lr = adjust_learning_rate(args, epoch)
    for param_group in optimizer.param_groups:
        #param_group["lr"] = lr
        if param_group["lr"] > 0.0001:
            current_lr = lr*(1/2)**(step/20000)
        else:
            if step_stage2 == 0:
                lr = current_lr
                step_stage2 = step_stage2 + 1
            current_lr = lr*(1/2)**(step_stage2/40000)
        param_group["lr"] = current_lr
        print("Epoch = {}, lr = {}".format(epoch, optimizer.param_groups[0]["lr"]))
    # for param_group in optimizer_D.param_groups:
    #     param_group["lr"] = current_lr

    epoch_loss = 0
    total_num = 0
    psnr_ssim_train = PSNR_SSIM_LPIPS()
    model.train()
    model_mae.train()
    start_time = time.time()
    for i, train_data in enumerate(train_dataloader, start=0):
        if step_stage2 == 0: 
            step = step + 1
        else:
            # step = step + 1
            step_stage2 = step_stage2 + 1
        #print('epoch_%04d(train) : %4d / %4d' % (epoch+1, step, len(train_dataloader)))
        optimizer.zero_grad()
        train_source1, train_target = train_data
        train_source1, train_target = train_source1.to(device), train_target.to(device)

        #train generator
        out_1, out_2, out_3 = model(train_source1)
        B, C, H, W = out_1.shape
        mask = (torch.rand(B, C, H, W) < args.mask_ratio).to(device)
        out_1_mask = torch.mul(out_1, mask)
        out_mae_1, out_mae_2, out_mae_3 = model_mae(out_1_mask)

        #compute tone loss
        out_mae_1_ycbcr = Variable(Tensor(torch.from_numpy(cv2.cvtColor(torch.clamp(out_mae_1.cpu(), 0, 1).mul(255).byte().numpy().squeeze(0).transpose((1, 2, 0)), cv2.COLOR_RGB2YCrCb)).float().div(255.0).to(device)), requires_grad=True)
        train_target_ycbcr = Variable(Tensor(torch.from_numpy(cv2.cvtColor(torch.clamp(train_target.cpu(), 0, 1).mul(255).byte().numpy().squeeze(0).transpose((1, 2, 0)), cv2.COLOR_RGB2YCrCb)).float().div(255.0).to(device)), requires_grad=True)
        loss_tone = (criterion_content(out_mae_1_ycbcr[:,:,1], train_target_ycbcr[:,:,1])+criterion_content(out_mae_1_ycbcr[:,:,2], train_target_ycbcr[:,:,2]))/2
        #compute self super loss
        out_mae_1_rgb = Variable(Tensor(torch.from_numpy(torch.clamp(out_1.cpu(), 0, 1).mul(255).byte().numpy().squeeze(0).transpose((1, 2, 0))).float().div(255.0).to(device)), requires_grad=True)
        loss_selfsuper = (criterion_content(out_mae_1_rgb[:,:,0], out_mae_1_rgb[:,:,1])+criterion_content(out_mae_1_rgb[:,:,2], out_mae_1_rgb[:,:,1]))/2

        loss_vgg = criterion(out_mae_1, out_mae_2, out_mae_3, train_target)
        # loss_content_gray = criterion_content(out_1_gray, target_1_gray)
        loss_content = criterion_content(out_mae_1, train_target)
        loss_fft = criterion_content(torch.fft.fft2(out_mae_1), torch.fft.fft2(train_target))

        loss_G = loss_vgg + args.LAM_COLOR * loss_tone *2 + args.LAM_COLOR * loss_selfsuper *2 + args.LAM_L1 *loss_content + args.LAM_FFT * loss_fft
        # loss_G = loss_vgg + args.LAM_L1 *loss_content + args.LAM_L1 *loss_content_gray + args.LAM_FFT * loss_fft #0.001->0.0001
        # print("loss_vgg: ", loss_vgg)
        # print("loss_content: ", loss_content)
        # print("loss_fft: ", loss_fft)
        loss_G.backward()
        optimizer.step()
        psnr_step, ssim_step, lpips_step = psnr_ssim_train.compute(out_mae_1, train_target)
        # print("psnr: ", psnr_step, "ssim: ", ssim_step, "lpips: ", lpips_step)

    elapsed_time = time.time() - start_time
    average_psnr, average_ssim, average_lpips = psnr_ssim_train.get_info()
    if average_psnr > best_train_psnr_performance:
        best_train_psnr_performance = average_psnr
        best_psnr_train_epoch = epoch + 1
    if average_ssim > best_train_ssim_performance:
        best_train_ssim_performance = average_ssim
        best_ssim_train_epoch = epoch + 1
    if average_lpips < best_train_lpips_performance:
        best_train_lpips_performance = average_lpips
        best_lpips_train_epoch = epoch + 1
    log('train epcoh = %04d , best_psnr_train_epoch = %04d , best_train_psnr= %4.4f, best_ssim_train_epoch = %04d , best_train_ssim= %4.4f, best_lpips_train_epoch = %04d , best_train_lpips= %4.4f, current_average_psnr = %4.4f , current_average_ssim = %4.4f, current_average_lpips = %4.4f, time = %4.2f s' % (
        epoch + 1, best_psnr_train_epoch, best_train_psnr_performance, best_ssim_train_epoch, best_train_ssim_performance, best_lpips_train_epoch, best_train_lpips_performance, average_psnr, average_ssim, average_lpips,
        elapsed_time))

    model.eval()
    model_mae.eval()
    # discriminator.eval()
    psnr_ssim_val = PSNR_SSIM_LPIPS()
    start_time = time.time()
    with torch.no_grad():
        for j, val_data in enumerate(val_dataloader, start=0):
            val_source1, val_target = val_data
            val_source1, val_target = val_source1.to(device), val_target.to(device)
            out_1, out_2, out_3 = model(val_source1)
            B, C, H, W = out_1.shape
            mask = (torch.rand(B, C, H, W) < args.mask_ratio).to(device)
            out_1_mask = torch.mul(out_1, mask)
            out_mae_1, out_mae_2, out_mae_3 = model_mae(out_1_mask)
            psnr_ssim_val.compute(out_mae_1, val_target)
        average_psnr, average_ssim, average_lpips = psnr_ssim_val.get_info()
        if average_psnr > 100:
            if (average_ssim) > (best_val_ssim_performance):
                best_val_ssim_performance = average_ssim
                best_ssim_val_epoch = epoch + 1
                torch.save(model.state_dict(), os.path.join(model_save_dir, 'best_G_psnr_inf_ssim.pth'))
                torch.save(model_mae.state_dict(), os.path.join(model_save_dir, 'best_G_MAE_psnr_inf_ssim.pth'))
                # torch.save(discriminator.state_dict(), os.path.join(model_save_dir, 'best_D_psnr_inf_ssim_gigagan_addfft_retrain_new_adddata.pth'))
            if (average_lpips) < (best_val_lpips_performance):
                best_val_lpips_performance = average_lpips
                best_lpips_val_epoch = epoch + 1
                torch.save(model.state_dict(), os.path.join(model_save_dir, 'best_G_psnr_inf_lpips.pth'))
                torch.save(model_mae.state_dict(), os.path.join(model_save_dir, 'best_G_MAE_psnr_inf_lpips.pth'))
                # torch.save(discriminator.state_dict(), os.path.join(model_save_dir, 'best_D_psnr_lpips_inf_gigagan_addfft_retrain_new_adddata.pth'))
        else:
            if (average_psnr) > (best_val_psnr_performance):
                best_val_psnr_performance = average_psnr
                best_psnr_val_epoch = epoch + 1
                torch.save(model.state_dict(), os.path.join(model_save_dir, 'best_G_psnr.pth'))
                torch.save(model_mae.state_dict(), os.path.join(model_save_dir, 'best_G_MAE_psnr.pth'))
                # torch.save(discriminator.state_dict(), os.path.join(model_save_dir, 'best_D_psnr_gigagan_addfft_retrain_new_adddata.pth'))
            if (average_ssim) > (best_val_ssim_performance):
                best_val_ssim_performance = average_ssim
                best_ssim_val_epoch = epoch + 1
                torch.save(model.state_dict(), os.path.join(model_save_dir, 'best_G_ssim.pth'))
                torch.save(model_mae.state_dict(), os.path.join(model_save_dir, 'best_G_MAE_ssim.pth'))
                # torch.save(discriminator.state_dict(), os.path.join(model_save_dir, 'best_D_ssim_gigagan_addfft_retrain_new_adddata.pth'))
            if (average_lpips) < (best_val_lpips_performance):
                best_val_lpips_performance = average_lpips
                best_lpips_val_epoch = epoch + 1
                torch.save(model.state_dict(), os.path.join(model_save_dir, 'best_G_lpips.pth'))
                torch.save(model_mae.state_dict(), os.path.join(model_save_dir, 'best_G_MAE_lpips.pth'))
                # torch.save(discriminator.state_dict(), os.path.join(model_save_dir, 'best_D_lpips_gigagan_addfft_retrain_new_adddata.pth'))
    elapsed_time = time.time() - start_time
    log('validation epcoh = %04d , best_psnr_val_epoch = %04d , best_val_psnr = %4.4f , best_ssim_val_epoch = %04d , best_val_ssim = %4.4f, best_lpips_val_epoch = %04d , best_val_lpips = %4.4f , current_average_psnr = %4.4f , current_average_ssim = %4.4f, current_average_lpips = %4.4f, time = %4.2f s' % (
            epoch + 1, best_psnr_val_epoch, best_val_psnr_performance, best_ssim_val_epoch, best_val_ssim_performance, best_lpips_val_epoch, best_val_lpips_performance, average_psnr, average_ssim, average_lpips, elapsed_time))
print('Train complete')