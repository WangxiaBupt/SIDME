%��ȡ�任���ָ��ͼ��
function im = sift_main(ori_image, guided_image)
    [matchLoc1, matchLoc2] = siftMatch(ori_image, guided_image);
    % use RANSAC to find homography matrix
    [H, corrPtIdx] = findHomography(matchLoc2',matchLoc1');
    H  %#ok
    tform = projective2d(H');
    im = imwarp(guided_image, tform,'OutputView',imref2d(size(ori_image))); % reproject img2
end

