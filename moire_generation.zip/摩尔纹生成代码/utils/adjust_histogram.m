function [img_cg_adjusted] = adjust_histogram(img_led,img_cg)
    %method1
    img_led=rgb2ycbcr(img_led);
    img_cg_warped=rgb2ycbcr(img_cg);
    im_camera_r=img_led(:,:,1);
    im_camera_g=img_led(:,:,2);
    im_camera_b=img_led(:,:,3);
%     
    [cr,r] = imhist(im_camera_r);
    [cg,g] = imhist(im_camera_g);
    [cb,b] = imhist(im_camera_b);
    
    im_cg_r=histeq(img_cg_warped(:,:,1), cr);
    im_cg_g=histeq(img_cg_warped(:,:,2), cg);
    im_cg_b=histeq(img_cg_warped(:,:,3), cb);
    
    [h,w,rgb]=size(img_cg);
    img_cg_adjusted=zeros(h,w,rgb);
    img_cg_adjusted(:,:,1)=im_cg_r(:,:);
    img_cg_adjusted(:,:,2)=im_cg_g(:,:);
    img_cg_adjusted(:,:,3)=im_cg_b(:,:);
    img_cg_adjusted=ycbcr2rgb(img_cg_adjusted);
end

