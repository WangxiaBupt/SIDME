function img_gt_adjust=adjust_lab(img_source,img_gt)
    img_gt_double=double(img_gt)/255;
    % img_gt=rgb2ycbcr(img_gt);
    % img_source=rgb2ycbcr(img_source);
    img_gt=rgb2lab(img_gt);
    img_source=rgb2lab(img_source);
    N=max(max(img_source(:)),max(img_gt(:)));
    M=min(min(img_source(:)),min(img_gt(:)));

    img_gt=(img_gt-M)/(N-M);
    img_source=(img_source-M)/(N-M);
    img_gt_uint=uint16(img_gt*1000);
    img_source_uint=uint16(img_source*1000);
    img_gt_adjust=img_gt;
    for cc=1:3
        img_gt_cc=img_gt_uint(:,:,cc);
        img_source_cc=img_source(:,:,cc);
        out_img_cc=double(img_source_cc);
        for v_i=0:1000
            idx=find(img_gt_cc==v_i);
            if size(idx,1)>0
                values=img_source_cc(idx);
                out_value=mean(values(:));
                out_img_cc(idx)=out_value;
            end
        end
    %     out_img_cc=uint8(out_img_cc);
        img_gt_adjust(:,:,cc)=out_img_cc(:,:);
    end

    img_gt_adjust=img_gt_adjust*(N-M)+M;
    % img_gt_adjust=ycbcr2rgb(img_gt_adjust);
    img_gt_adjust=lab2rgb(img_gt_adjust);
end