function mask = find_mask(input_image)
    %FIND_MASK find the element of zero in input_image
    [h, w, c] = size(input_image);
    mask = ones(h, w);
    for i = 1:h
        for j = 1:w
            if (input_image(i, j, 1)==0 && input_image(i, j, 2)==0 && input_image(i, j, 3)==0)
                mask(i, j) = 0;
            end
        end
    end
end

