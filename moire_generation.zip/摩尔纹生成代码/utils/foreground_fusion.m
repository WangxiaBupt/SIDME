function fusion_image = foreground_fusion(back_ground,fore_ground)
    [h, w, ~] = size(back_ground);
    fusion_image = fore_ground;
    for i = 1:h
        for j = 1:w
            if (fore_ground(i, j, 1) < 1/255 && fore_ground(i, j, 2)< 1/255 && fore_ground(i, j, 3)< 1/255)
                fusion_image(i, j, :) = back_ground(i, j, :);
            end
        end
    end
end

