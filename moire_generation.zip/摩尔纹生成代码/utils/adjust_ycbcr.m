function img_gt_adjust_smooth=adjust_ycbcr(img_source,img_gt)
    img_gt_double=double(img_gt)/255;

    img_gt=rgb2ycbcr(img_gt);
    img_source=rgb2ycbcr(img_source);
    % img_gt=rgb2lab(img_gt);
    % img_source=rgb2lab(img_source);
    N=max(max(img_source(:)),max(img_gt(:)));
    M=min(min(img_source(:)),min(img_gt(:)));
    N=double(N);
    M=double(M);

    img_gt=double(img_gt-M)/double(N-M);
    img_source=double(img_source-M)/double(N-M);
    img_gt_uint=uint16(img_gt*1000);
    img_source_uint=uint16(img_source*1000);
    img_gt_adjust=img_gt;
    for cc=1:3
        img_gt_cc=img_gt_uint(:,:,cc);
        img_source_cc=img_source(:,:,cc);
        out_img_cc=double(img_source_cc);
        for v_i=0:1000
            idx=find(img_gt_cc==v_i);
            if size(idx,1)>0
                values=img_source_cc(idx);
                out_value=mean(values(:));
                out_img_cc(idx)=out_value;
            end
        end
    %     out_img_cc=uint8(out_img_cc);
        img_gt_adjust(:,:,cc)=out_img_cc(:,:);
    end

    img_gt_adjust=img_gt_adjust*(N-M)+M;
    % img_gt_adjust=ycbcr2rgb(img_gt_adjust);
    % img_gt_adjust=lab2rgb(img_gt_adjust);
    img_gt_adjust=ycbcr2rgb(img_gt_adjust/255);

    img_gt_adjust_smooth=img_gt_adjust;
    % ratio=img_gt_adjust./img_gt_double;
    img_gt_double=rgb2ycbcr(img_gt_double);
    img_gt_adjust=rgb2ycbcr(img_gt_adjust);
    for cc=1:3
        img_gt_cc=img_gt_double(:,:,cc);
        img_gt_3dlut_cc=img_gt_adjust(:,:,cc);
        img_gt_cc=max(img_gt_cc,0.5/255);
        ratio=img_gt_3dlut_cc./img_gt_cc;
        N=max(ratio(:));
        ratio=ratio/N;
        
        nhoodSize = 7;%150;
        smoothValue  = 0.003;%0.5;
        A=ratio;
        G=img_gt_cc;
        
        ratio_new = imguidedfilter(A, G, ...
            'NeighborhoodSize', nhoodSize, 'DegreeOfSmoothing',smoothValue);
        
        ratio_new=ratio_new*N;
        img_tmp=ratio_new.*img_gt_cc;
        img_gt_adjust_smooth(:,:,cc)=img_tmp(:,:);
        
    end
    img_gt_adjust_smooth=ycbcr2rgb(img_gt_adjust_smooth);

end