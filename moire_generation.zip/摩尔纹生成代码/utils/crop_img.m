function [image_gt_crop, image_moire1_crop, image_moire2_crop] = crop_img(image_gt, image_moire1, image_moire2)
    %compute crop area
    [h, w, c] = size(image_gt);
    min_h1 = 1;
    max_h1 = h;
    min_w1 = 1;
    max_w1 = w;
    for i = 1:h
        for j = 1:w-1
            if image_moire1(i, j, 1) == 0 && image_moire1(i, j, 2) == 0 && image_moire1(i, j, 3) == 0
                if j<w && (image_moire1(i, j+1, 1) ~= 0 || image_moire1(i, j+1, 2) ~= 0 || image_moire1(i, j+1, 3) ~= 0) && j>min_w1
                    min_w1 = j;
                end
                if j>1 && (image_moire1(i, j-1, 1) == 0 || image_moire1(i, j-1, 2) == 0 || image_moire1(i, j-1, 3) == 0) && (image_moire1(i, j+1, 1) == 0 && image_moire1(i, j+1, 2) == 0 && image_moire1(i, j+1, 3) == 0) && j<max_w1
                    max_w1 = j;
                    break;
                end
            end
        end
    end
    for j = 1:w
        for i = 1:h-1
            if image_moire1(i, j, 1) == 0 && image_moire1(i, j, 2) == 0 && image_moire1(i, j, 3) == 0
                if i<h && (image_moire1(i+1, j, 1) ~= 0 || image_moire1(i+1, j, 2) ~= 0 || image_moire1(i+1, j, 3) ~= 0) && i>min_h1
                    min_h1 = i;
                end
                if i>1 && (image_moire1(i-1, j, 1) ~= 0 || image_moire1(i-1, j, 2) ~= 0 || image_moire1(i-1, j, 3) ~= 0) && (image_moire1(i+1, j, 1) == 0 && image_moire1(i+1, j, 2) == 0 && image_moire1(i+1, j, 3) == 0) && i<max_h1
                    max_h1 = i;
                    break;
                end
            end
        end
    end
    min_h2 = 1;
    max_h2 = h;
    min_w2 = 1;
    max_w2 = w;
    for i = 1:h
        for j = 1:w-1
            if image_moire2(i, j, 1) == 0 && image_moire2(i, j, 2) == 0 && image_moire2(i, j, 3) == 0
                if j<w && (image_moire2(i, j+1, 1) ~= 0 || image_moire2(i, j+1, 2) ~= 0 || image_moire2(i, j+1, 3) ~= 0) && j>min_w2
                    min_w2 = j;
                end
                if j>1 && (image_moire2(i, j-1, 1) ~= 0 || image_moire2(i, j-1, 2) ~= 0 || image_moire2(i, j-1, 3) ~= 0) && (image_moire2(i, j+1, 1) == 0 && image_moire2(i, j+1, 2) == 0 && image_moire2(i, j+1, 3) == 0) && j<max_w2
                    max_w2 = j;
                    break;
                end
            end
        end
    end
    for j = 1:w
        for i = 1:h-1
            if image_moire2(i, j, 1) == 0 && image_moire2(i, j, 2) == 0 && image_moire2(i, j, 3) == 0
                if i<h && (image_moire2(i+1, j, 1) ~= 0 || image_moire2(i+1, j, 2) ~= 0 || image_moire2(i+1, j, 3) ~= 0) && i>min_h2
                    min_h2 = i;
                end
                if i>1 && (image_moire2(i-1, j, 1) ~= 0 || image_moire2(i-1, j, 2) ~= 0 || image_moire2(i-1, j, 3) ~= 0) && (image_moire2(i+1, j, 1) == 0 && image_moire2(i+1, j, 2) == 0 && image_moire2(i+1, j, 3) == 0) && i<max_h2
                    max_h2 = i;
                    break;
                end
            end
        end
    end
    min_h = max(min_h1, min_h2);
    max_h = min(max_h1, max_h2);
    min_w = max(min_w1, min_w2);
    max_w = min(max_w1, max_w2);
    image_gt_crop = image_gt(min_h:max_h, min_w:max_w, :);
    image_moire1_crop = image_moire1(min_h:max_h, min_w:max_w, :);
    image_moire2_crop = image_moire2(min_h:max_h, min_w:max_w, :);
end

