function res_img=enhance(source,target,kernel_size)
source=uint32(source);
target=uint32(target);
res_img = zeros(size(source),'uint32');
for channel = 1:3
    lumi_space_target = double(zeros(kernel_size, kernel_size, kernel_size));
    lumi_space_source = double(zeros(kernel_size, kernel_size, kernel_size));
%     lumi_space = double(zeros(kernel_size, kernel_size, kernel_size));
%     lumi_mean = double(zeros(kernel_size, kernel_size, kernel_size));
    for w =1:size(source,1)
        for h =1:size(source,2)
            r = ceil(((double(source(w, h, 1))+1)/256)*kernel_size);
            g = ceil(((double(source(w, h, 2))+1)/256)*kernel_size);
            b = ceil(((double(source(w, h, 3))+1)/256)*kernel_size);
%             lumi_space(r, g, b) = double(target(w, h, channel)+1)/double(source(w, h, channel)+1) + lumi_space(r, g, b);
%             lumi_mean(r, g, b)=lumi_mean(r,g,b)+1;
%             r = round((source(w, h, 1)+1)/kernel_size+1);
%             g = round((source(w, h, 2)+1)/kernel_size+1);
%             b = round((source(w, h, 3)+1)/kernel_size+1);
            lumi_space_target(r, g, b) = double(target(w, h, channel)) + lumi_space_target(r, g, b);
            lumi_space_source(r, g, b) = double(source(w, h, channel)) + lumi_space_source(r, g, b);
%             lumi_mean(r, g, b)=lumi_mean(r,g,b)+1;
        end
    end   
    for w =1:size(source,1)
        for h =1:size(source,2)
            r = ceil(((double(source(w, h, 1))+1)/256)*kernel_size);
            g = ceil(((double(source(w, h, 2))+1)/256)*kernel_size);
            b = ceil(((double(source(w, h, 3))+1)/256)*kernel_size);
%             res_img(w, h,channel) = ceil(source(w, h, channel)*(lumi_space(r, g, b) / lumi_mean(r, g, b)));
%             r = round((source(w, h, 1)+1)/kernel_size+1);
%             g = round((source(w, h, 2)+1)/kernel_size+1);
%             b = round((source(w, h, 3)+1)/kernel_size+1);
            res_img(w, h,channel) = ceil(source(w, h, channel)*(lumi_space_target(r, g, b) / lumi_space_source(r, g, b)));
        end
    end
end
    %res_img
res_img=uint8(res_img);
    %imwrite(res_img,'./res.png');
    %whos res_img;

end