clear all;
addpath(fullfile(pwd,'sift'));
addpath(fullfile(pwd,'utils'));
file_path = 'inputs_weak/';
image_path_list = dir(strcat(file_path, '*.png'));
img_save_path = 'outputs_weak/';
datasets_save_path = 'outputs_weak/';
start_num = 1;
end_num = length(image_path_list);
end_num

if ~isfolder(img_save_path)
    mkdir(img_save_path);
end
if ~isfolder(datasets_save_path)
    mkdir(datasets_save_path);
end

save_num = 881;
err_num = 0;
kernel_size = 32;
for index = start_num:end_num
    index+save_num
    tic;
    image_input = imread([file_path, image_path_list(index).name]);
    image_input_resize = image_input;
    %image_input_resize = imresize(image_input, 0.3);
    [h, w, c] = size(image_input_resize);
    if c==3
        try
        if max(h, w) >= 2100
            ratio = 2100/max(h, w);
            image_input_resize = imresize(image_input, ratio);
        end
        [h, w, c] = size(image_input_resize);
        %resampling
        i_times_1 = 9;
        j_times_1 = 3;
        i_times_2 = 9;
        j_times_2 = 3;
        start_ratio = 0.04;
        end_ratio = 0.96;
        image_resample_moire_1 = uint8(zeros(i_times_1*h, 3*j_times_1*w));
        image_resample_moire_1_flag = uint8(zeros(i_times_1*h, 3*j_times_1*w));
        for i = 1 : h
            for j = 1 : w
                for k = 1 : 3
                for p = 1 : i_times_1
                for q = 1 : j_times_1
                    image_resample_moire_1(i_times_1*(i-1)+p,j_times_1*3*(j-1)+3*(q-1)+k) = image_input_resize(i, j, k);
                    image_resample_moire_1_flag(i_times_1*(i-1)+p,j_times_1*3*(j-1)+3*(q-1)+k) = k;
                end
                end
                end
            end
        end
        %Projective transformation
        t11=rand()*start_ratio;t12=rand()*start_ratio+end_ratio;t13=rand()*start_ratio;t14=rand()*start_ratio+end_ratio;t15=rand()*start_ratio;t16=rand()*start_ratio;t17=rand()*start_ratio+end_ratio;t18=rand()*start_ratio+end_ratio;
        [t11, t12, t13, t14; t15, t16 t17, t18]
        [h1, w1, c] = size(image_resample_moire_1);
        p11=[1, h1, 1, h1; 1, 1, w1, w1];
        p12=[round(t11*h1), round(t12*h1), round(t13*h1), round(t14*h1); round(t15*w1), round(t16*w1), round(t17*w1), round(t18*w1)];
        [H1 corrPtIdx1] = findHomography(p11,p12);
            
        tform1 = projective2d(H1');
        image_resample_persptrans_moire_1  = imwarp(image_resample_moire_1, tform1,'OutputView',imref2d(size(image_resample_moire_1)));
        image_flag_persptrans_moire_2  = imwarp(image_resample_moire_1_flag, tform1,'OutputView',imref2d(size(image_resample_moire_1_flag)));
        clear image_resample_moire_1;
        clear image_resample_moire_1_flag;
            
        %gauss filter
        image_gauss_moire_1 = imgaussfilt(image_resample_persptrans_moire_1, 'FilterSize',3);
        clear image_resample_persptrans_moire_1;
            
        %resample image using bayer CFA to simulate raw image data
        [h1, w1, c] = size(image_gauss_moire_1);
        image_bayer_moire_1 = uint8(zeros(h1, w1));
        rgb_gain_1 = [0.0, 0.0, 0.0];
        rgb_sum_1 = [0.0, 0.0, 0.0];
        for i=1:2:h1
            for j=1:2:w1
                rgb_sum_1(1) = rgb_sum_1(1) + 1;
                if image_flag_persptrans_moire_2(i, j)==1
                    rgb_gain_1(1) = rgb_gain_1(1) + 1;
                    image_bayer_moire_1(i, j) = image_gauss_moire_1(i, j);
                else
                    if j+1 <=w1
                        if image_flag_persptrans_moire_2(i, j+1)==1
                            rgb_gain_1(1) = rgb_gain_1(1) + 1;
                            image_bayer_moire_1(i, j) = image_gauss_moire_1(i, j+1);
                        else 
                            if i+1 <=h1
                                if image_flag_persptrans_moire_2(i+1, j)==1
                                    rgb_gain_1(1) = rgb_gain_1(1) + 1;
                                    image_bayer_moire_1(i, j) = image_gauss_moire_1(i+1, j);
                                else
                                    if image_flag_persptrans_moire_2(i+1, j+1)==1
                                        rgb_gain_1(1) = rgb_gain_1(1) + 1;
                                        image_bayer_moire_1(i, j) = image_gauss_moire_1(i+1, j+1);
                                    end
                                end
                            end
                        end
                    end
                end
                if j+1 <=w1
                    rgb_sum_1(2) = rgb_sum_1(2) + 1;
                    if image_flag_persptrans_moire_2(i, j+1)==2
                        rgb_gain_1(2) = rgb_gain_1(2) + 1;
                        image_bayer_moire_1(i, j+1) = image_gauss_moire_1(i, j+1);
                    end
                end
                if i+1 <=h1
                    rgb_sum_1(2) = rgb_sum_1(2) + 1;
                    if image_flag_persptrans_moire_2(i+1, j)==2
                        rgb_gain_1(2) = rgb_gain_1(2) + 1;
                        image_bayer_moire_1(i+1, j) = image_gauss_moire_1(i+1, j);
                    end
                end
                if i+1 <=h1 && j+1 <=w1
                    rgb_sum_1(3) = rgb_sum_1(3) + 1;
                    if image_flag_persptrans_moire_2(i+1, j+1)==3
                        rgb_gain_1(3) = rgb_gain_1(3) + 1;
                        image_bayer_moire_1(i+1, j+1) = image_gauss_moire_1(i+1, j+1);
                    elseif image_flag_persptrans_moire_2(i, j)==3
                        rgb_gain_1(3) = rgb_gain_1(3) + 1;
                        image_bayer_moire_1(i+1, j+1) = image_gauss_moire_1(i, j);
                    elseif image_flag_persptrans_moire_2(i, j+1)==3
                        rgb_gain_1(3) = rgb_gain_1(3) + 1;
                        image_bayer_moire_1(i+1, j+1) = image_gauss_moire_1(i, j+1);
                    elseif image_flag_persptrans_moire_2(i+1, j)==3
                        rgb_gain_1(3) = rgb_gain_1(3) + 1;
                        image_bayer_moire_1(i+1, j+1) = image_gauss_moire_1(i+1, j);
                    end
                end
            end
        end
        clear image_gauss_moire_1;
        clear image_flag_persptrans_moire_1;
                        
        %Apply demosaicing
        image_bayer_moire_1_to_uint = image_bayer_moire_1;
        image_demosaic_moire_1_ori = demosaic(image_bayer_moire_1_to_uint, 'rggb');
        image_demosaic_moire_1_ori_resize = imresize(image_demosaic_moire_1_ori, [h, w]);
        image_jpegcompress_moire_1 = JPEGEncodeDecode(image_demosaic_moire_1_ori_resize);
        image_jpegcompress_moire_1 = image_jpegcompress_moire_1;
        clear image_bayer_moire_1;
        clear image_demosaic_moire_1;

        %error('stop')  
        %resample
        image_resample_moire_2 = uint8(zeros(i_times_2*h, 3*j_times_2*w));
        image_resample_moire_2_flag = uint8(zeros(i_times_1*h, 3*j_times_1*w));
        for i = 1 : h
            for j = 1 : w
                for k = 1 : 3
                for p = 1 : i_times_2
                for q = 1 : j_times_2
                    image_resample_moire_2(i_times_2*(i-1)+p,j_times_2*3*(j-1)+3*(q-1)+k) = image_input_resize(i, j, k);
                    image_resample_moire_2_flag(i_times_2*(i-1)+p,j_times_2*3*(j-1)+3*(q-1)+k) = k;
                end
                end
                end
            end
        end
        %Projective transformation
        t11_2=rand()*start_ratio;t12_2=rand()*start_ratio+end_ratio;t13_2=rand()*start_ratio;t14_2=rand()*start_ratio+end_ratio;t15_2=rand()*start_ratio;t16_2=rand()*start_ratio;t17_2=rand()*start_ratio+end_ratio;t18_2=rand()*start_ratio+end_ratio;
        [h2, w2, c] = size(image_resample_moire_2);
        p21=[1, h2, 1, h2; 1, 1, w2, w2];
        p22=[round(t11_2*h2), round(t12_2*h2), round(t13_2*h2), round(t14_2*h2); round(t15_2*w2), round(t16_2*w2), round(t17_2*w2), round(t18_2*w2)];
        [H2 corrPtIdx2] = findHomography(p21,p22);
        %H  %#ok
        tform2 = projective2d(H2');
        image_resample_persptrans_moire_2  = imwarp(image_resample_moire_2, tform2,'OutputView',imref2d(size(image_resample_moire_2)));
        image_flag_persptrans_moire_2  = imwarp(image_resample_moire_2_flag, tform2,'OutputView',imref2d(size(image_resample_moire_2_flag)));
        clear image_resample_moire_2;
        clear image_resample_moire_2_flag;
        
        %gauss filter
        image_gauss_moire_2 = imgaussfilt(image_resample_persptrans_moire_2, 'FilterSize',3);
        clear image_resample_persptrans_moire_2;
            
        %resample image using bayer CFA to simulate raw image data
        [h2, w2, c] = size(image_gauss_moire_2);
        image_bayer_moire_2 = uint8(zeros(h2, w2));
        rgb_gain_2 = [0.0, 0.0, 0.0];
        rgb_sum_2 = [0.0, 0.0, 0.0];
        for i=1:2:h2
            for j=1:2:w2
                rgb_sum_2(1) = rgb_sum_2(1) + 1;
                if image_flag_persptrans_moire_2(i, j)==1
                    rgb_gain_2(1) = rgb_gain_2(1) + 1;
                    image_bayer_moire_2(i, j) = image_gauss_moire_2(i, j);
                else
                    if j+1 <=w2
                        if image_flag_persptrans_moire_2(i, j+1)==1
                            rgb_gain_2(1) = rgb_gain_2(1) + 1;
                            image_bayer_moire_2(i, j) = image_gauss_moire_2(i, j+1);
                        else 
                            if i+1 <=h2
                                if image_flag_persptrans_moire_2(i+1, j)==1
                                    rgb_gain_2(1) = rgb_gain_2(1) + 1;
                                    image_bayer_moire_2(i, j) = image_gauss_moire_2(i+1, j);
                                else
                                    if image_flag_persptrans_moire_2(i+1, j+1)==1
                                        rgb_gain_2(1) = rgb_gain_2(1) + 1;
                                        image_bayer_moire_2(i, j) = image_gauss_moire_2(i+1, j+1);
                                    end
                                end
                            end
                        end
                    end
                end
                if j+1 <=w2
                    rgb_sum_2(2) = rgb_sum_2(2) + 1;
                    if image_flag_persptrans_moire_2(i, j+1)==2
                        rgb_gain_2(2) = rgb_gain_2(2) + 1;
                        image_bayer_moire_2(i, j+1) = image_gauss_moire_2(i, j+1);
                    end
                end
                if i+1 <=h2
                    rgb_sum_2(2) = rgb_sum_2(2) + 1;
                    if image_flag_persptrans_moire_2(i+1, j)==2
                        rgb_gain_2(2) = rgb_gain_2(2) + 1;
                        image_bayer_moire_2(i+1, j) = image_gauss_moire_2(i+1, j);
                    end
                end
                if i+1 <=h2 && j+1 <=w2
                    rgb_sum_2(3) = rgb_sum_2(3) + 1;
                    if image_flag_persptrans_moire_2(i+1, j+1)==3
                        rgb_gain_2(3) = rgb_gain_2(3) + 1;
                        image_bayer_moire_2(i+1, j+1) = image_gauss_moire_2(i+1, j+1);
                    elseif image_flag_persptrans_moire_2(i, j)==3
                        rgb_gain_2(3) = rgb_gain_2(3) + 1;
                        image_bayer_moire_2(i+1, j+1) = image_gauss_moire_2(i, j);
                    elseif image_flag_persptrans_moire_2(i, j+1)==3
                        rgb_gain_2(3) = rgb_gain_2(3) + 1;
                        image_bayer_moire_2(i+1, j+1) = image_gauss_moire_2(i, j+1);
                    elseif image_flag_persptrans_moire_2(i+1, j)==3
                        rgb_gain_2(3) = rgb_gain_2(3) + 1;
                        image_bayer_moire_2(i+1, j+1) = image_gauss_moire_2(i+1, j);
                    end
                end
            end
        end
        clear image_gauss_moire_2;
        clear image_flag_persptrans_moire_2;
            
        %Apply demosaicing
        image_bayer_moire_2_to_uint = image_bayer_moire_2;
        % image_demosaic_moire_2_ori = demosaic(image_bayer_moire_2_to_uint, 'rggb');
        [H2_1 corrPtIdx2] = findHomography(p22,p12);
        tform2_1 = projective2d(H2_1');
        image_bayer_moire_2_to_uint  = imwarp(image_bayer_moire_2_to_uint, tform2_1,'OutputView',imref2d(size(image_bayer_moire_2_to_uint)));      
        image_bayer_moire_2_to_uint_resize = imresize(image_bayer_moire_2_to_uint, [h, w]);
        clear image_bayer_moire_2;
        % clear image_demosaic_moire_2;
            
        %generate ground truth
        i_times_3 = 6;
        j_times_3 = 6;
        %generate ground truth
        image_resample_gt = uint8(zeros(i_times_3*h, 3*j_times_3*w,2));
        for i = 1 : h
            for j = 1 : w
                for k = 1 : 3
                for p = 1 : i_times_3
                for q = 1 : j_times_3
                    image_resample_gt(i_times_3*(i-1)+p,j_times_3*3*(j-1)+3*(q-1)+k,1) = image_input_resize(i, j, k);
                    image_resample_gt(i_times_3*(i-1)+p,j_times_3*3*(j-1)+3*(q-1)+k,2) = k;
                end
                end
                end
            end
        end
%           image_flag_persptrans_gt = image_resample_gt(:,:,2);
        image_resample_persptrans_gt = image_resample_gt(:,:,1);
        image_gauss_gt = imgaussfilt(image_resample_persptrans_gt, 'FilterSize',3);
        [h3, w3, c] = size(image_gauss_gt);
        image_bayer_gt = uint8(zeros(h3, w3/3));
        [h4, w4, c] = size(image_bayer_gt);
        for i=1:2:h4
            for j=1:2:w4
                image_bayer_gt(i, j) = image_gauss_gt(i, (j-1)*3+1);
                if j+1<=w4
                    image_bayer_gt(i, j+1) = image_gauss_gt(i, (j-1)*3+5);
                end
                if i+1<=h4
                    image_bayer_gt(i+1, j) = image_gauss_gt(i+1, (j-1)*3+2);
                end
                if i+1<=h4 && j+1<=w4
                    image_bayer_gt(i+1, j+1) = image_gauss_gt(i+1, (j-1)*3+6);
                end
            end
        end
        image_bayer_gt_to_uint = image_bayer_gt;
        image_demosaic_gt_ori = demosaic(image_bayer_gt_to_uint, 'rggb');
        [h5, w5, c] = size(image_demosaic_gt_ori);
        p31=[1, h5, 1, h5; 1, 1, w5, w5];
        p32=[round(t11*h5), round(t12*h5), round(t13*h5), round(t14*h5); round(t15*w5), round(t16*w5), round(t17*w5), round(t18*w5)];
        [H3 corrPtIdx1] = findHomography(p31,p32);
            
        tform3 = projective2d(H3');
        image_demosaic_gt  = imwarp(image_demosaic_gt_ori, tform3,'OutputView',imref2d(size(image_demosaic_gt_ori)));
        image_demosaic_gt_resize = imresize(image_demosaic_gt, [h, w]);
        %image_jpegcompress_gt = JPEGEncodeDecode(image_demosaic_gt_resize);
        image_jpegcompress_gt = image_demosaic_gt_resize;
        
        image_gt_crop = image_jpegcompress_gt;
        image_moire1_crop = image_jpegcompress_moire_1;
        image_moire2_crop = image_bayer_moire_2_to_uint_resize;
        if max(h,w)*(end_ratio-start_ratio) >=1920
            image_gt_crop = image_jpegcompress_gt(round(h*start_ratio):round(h*end_ratio), round(w*start_ratio):round(w*end_ratio), :);
            image_moire1_crop = image_jpegcompress_moire_1(round(h*start_ratio):round(h*end_ratio), round(w*start_ratio):round(w*end_ratio), :);
            image_moire2_crop = image_bayer_moire_2_to_uint_resize(round(h*start_ratio):round(h*end_ratio), round(w*start_ratio):round(w*end_ratio), :);
        else
            crop_ratio = (1-1920/max(h, w))/2;
            image_gt_crop = image_jpegcompress_gt(round(h*crop_ratio):round(h*(1-crop_ratio)), round(w*crop_ratio):round(w*(1-crop_ratio)), :);
            image_moire1_crop = image_jpegcompress_moire_1(round(h*crop_ratio):round(h*(1-crop_ratio)), round(w*crop_ratio):round(w*(1-crop_ratio)), :);
            image_moire2_crop = image_bayer_moire_2_to_uint_resize(round(h*crop_ratio):round(h*(1-crop_ratio)), round(w*crop_ratio):round(w*(1-crop_ratio)), :);
        end

        [h_out, w_out, c] = size(image_gt_crop);
        h_gap = mod(h_out, 64);
        w_gap = mod(w_out, 64);
        image_gt_crop_for_64 = image_gt_crop(floor(h_gap/2)+1:h_out-(h_gap-floor(h_gap/2)),floor(w_gap/2)+1:w_out-(w_gap-floor(w_gap/2)), :);
        image_moire1_crop_for_64 = image_moire1_crop(floor(h_gap/2)+1:h_out-(h_gap-floor(h_gap/2)),floor(w_gap/2)+1:w_out-(w_gap-floor(w_gap/2)), :);
        image_moire2_crop_for_64 = image_moire2_crop(floor(h_gap/2)+1:h_out-(h_gap-floor(h_gap/2)),floor(w_gap/2)+1:w_out-(w_gap-floor(w_gap/2)), :);


        %image_gt_save_name = [img_save_path, num2str(index+save_num, '%04d'), '_target_ori.png'];
        
        image_moire1_adjust_result_save_name = [datasets_save_path, num2str(index+save_num, '%04d'), '_moire_rgb.png'];
        image_moire2_adjust_result_save_name = [datasets_save_path, num2str(index+save_num, '%04d'), '_moire_gray.png'];
        image_gt_adjust_ori_save_name = [datasets_save_path, num2str(index+save_num, '%04d'), '_target.png'];
        
        image_moire1_adjust_resample_ratio = image_moire1_crop_for_64;
        image_moire1_adjust_result_ratio = image_moire1_crop_for_64;
        image_moire2_adjust_resample_ratio = image_moire2_crop_for_64;
        image_moire2_adjust_result_ratio = image_moire2_crop_for_64;
        % for cc = 1 : 3
        %     image_gt_cc = image_gt_crop_for_64(:,:,cc);
        %     image_moire1_cc = image_moire1_crop_for_64(:,:,cc);
        %     image_moire2_cc = image_moire2_crop_for_64(:,:,cc);
        %     %image_moire1_adjust_resample_ratio(:,:,cc) = image_moire1_crop_for_64(:,:,cc)/(rgb_gain_1(cc)/rgb_sum_1(cc));
        %     image_moire1_adjust_result_ratio(:,:,cc) = image_moire1_crop_for_64(:,:,cc)/(mean(image_moire1_cc(:))/mean(image_gt_cc(:)));
        %     %image_moire2_adjust_resample_ratio(:,:,cc) = image_moire2_crop_for_64(:,:,cc)/(rgb_gain_2(cc)/rgb_sum_2(cc));
        %     image_moire2_adjust_result_ratio(:,:,cc) = image_moire2_crop_for_64(:,:,cc)/(mean(image_moire2_cc(:))/mean(image_gt_cc(:)));
        % end
        image_moire1_adjust_result_ratio_uint = image_moire1_adjust_result_ratio;
        image_gt_crop_for_64_uint = image_gt_crop_for_64;

        image_gt_crop_for_64_ycbcr=rgb2ycbcr(image_gt_crop_for_64);
        image_moire1_adjust_result_ratio_ycbcr=rgb2ycbcr(image_moire1_adjust_result_ratio);
        img_gt_adjust=image_gt_crop_for_64_ycbcr;
        for cc=1:3
            img_gt_cc=image_gt_crop_for_64_ycbcr(:,:,cc);
            img_source_cc=image_moire1_adjust_result_ratio_ycbcr(:,:,cc);
            out_img_cc=double(img_source_cc);
            for v_i=0:255
                idx=find(img_gt_cc==v_i);
                if size(idx,1)>0
                    values=img_source_cc(idx);
                    out_value=mean(values(:));
                    out_img_cc(idx)=out_value;
                end
            end
            out_img_cc=uint8(out_img_cc);
            img_gt_adjust(:,:,cc)=out_img_cc(:,:);
        end
        img_gt_adjust=ycbcr2rgb(img_gt_adjust);

        %imwrite(image_gt_crop_for_64, image_gt_save_name);
        imwrite(image_moire1_adjust_result_ratio, image_moire1_adjust_result_save_name);
        imwrite(image_moire2_adjust_result_ratio, image_moire2_adjust_result_save_name);
        imwrite(img_gt_adjust, image_gt_adjust_ori_save_name);
        catch
            err_num = err_num + 1;
        end  
    end
    toc;
end
% err_num